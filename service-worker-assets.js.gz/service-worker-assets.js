self.assetsManifest = {
  "version": "oDkVDKH/",
  "assets": [
    {
      "hash": "sha256-FqTaEL8BV9TzyL9nukyntnIBb53h0pKRWBtQP5F09MY=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-8+iZ8ET0xqP09OvKHJWYGFCjPZyiASD7Kl1tcdK6rj0=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-mcbvezLSE54WUoeu+zLNqFQWr0n/zI8QjrXUzFZOMBU=",
      "url": "_framework/MathGame.Web.5h7fb6zct1.wasm"
    },
    {
      "hash": "sha256-6TjAnwK83qx2u7jJRERCUpe4alFqntX4/M0Mk/AXYRA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.p4cmqynr10.wasm"
    },
    {
      "hash": "sha256-Od/f5NEq5nkpRn+aUYzYU17rRaVtFanjk2WIjLkw++M=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.94yub77kjf.wasm"
    },
    {
      "hash": "sha256-fX/L2lJJw7tJ1zuXtXmpsq7yDqCE3RO+uKShwe3uc5w=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.t84gqnz3bz.wasm"
    },
    {
      "hash": "sha256-lnjkwwi3Nj/wRfNCxzf7slfa7OGXVTH/vapWJwjW28U=",
      "url": "_framework/Microsoft.AspNetCore.Components.ejff7h4ctd.wasm"
    },
    {
      "hash": "sha256-KTJm6BIGGNfU41wPO6lMNMmUXnYFaXuEKjNy5ruOo0Y=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vqddrv70hy.wasm"
    },
    {
      "hash": "sha256-5MlajQ4o5ZSc9+Ao6RVRqh7puGzeJ+Y6tFld+O2tTZo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.8dcqd2oqkg.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-VuCbmTALXSkHmTYi8RNzMq9BkQ7KsOyNYXB3rWcE4ws=",
      "url": "_framework/Microsoft.Extensions.Configuration.ei421noawx.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-GRQq7ef/04D4/bLwnP0ipSoY8q2sLy/bt8ZvmIDJFf0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bfssx3wjn3.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-Gc7Oqk4/9MAtp0l7ESF6JgqIYusSvnbJXnLHUhPW9FY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.5layk8frqd.wasm"
    },
    {
      "hash": "sha256-720xjccNSC/ixI8d5toBVmd5GGEzQAIN2LMqBmflaJw=",
      "url": "_framework/Microsoft.Extensions.Options.1cu2gj5cau.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-xtQtSoK56ZLcZdr1TPIw4dex5O90dyRzRhWC9Coj9J8=",
      "url": "_framework/Microsoft.JSInterop.agnux60n3l.wasm"
    },
    {
      "hash": "sha256-DDc4XP52nCefdg88+S3NR4gXfkvc/nNkWXbi5mI0Uy0=",
      "url": "_framework/MudBlazor.wh7g7avib4.wasm"
    },
    {
      "hash": "sha256-QjQ6utjYHdY41hNeYWVu2zAlD0HMOaSAsupG4nYupVU=",
      "url": "_framework/System.Collections.Concurrent.a6y58o9o0r.wasm"
    },
    {
      "hash": "sha256-5jk1zDjYBP4Rnf173IUiZvqf/cuSdTgoUyn275rmeR4=",
      "url": "_framework/System.Collections.Immutable.2x4sigubxy.wasm"
    },
    {
      "hash": "sha256-VE9PJMXPBzhvkhMLSeTrzWKoNmzHGGuJCmNbK+j4MRw=",
      "url": "_framework/System.Collections.NonGeneric.4obdry5n9j.wasm"
    },
    {
      "hash": "sha256-IeeUFOcST5K7LbflOS2kQW0/QEQOD09z/jX2uV2jv7o=",
      "url": "_framework/System.Collections.Specialized.fcaqy8qtnc.wasm"
    },
    {
      "hash": "sha256-1If3Z/+GU5hHXGOZmraAuVbWc65wmw+ANs90aAZIl1c=",
      "url": "_framework/System.Collections.ofmh0rrcqs.wasm"
    },
    {
      "hash": "sha256-1CIZA9hWUQ5UCDgcUmMhltw8QAOEZgnMrWYHqd+VXME=",
      "url": "_framework/System.ComponentModel.87xnj6x1yw.wasm"
    },
    {
      "hash": "sha256-1RudhU6Nb/vekxIJe1QPflINN+mbcSKzjB79UJ2sHOY=",
      "url": "_framework/System.ComponentModel.Annotations.fnadxzkcbt.wasm"
    },
    {
      "hash": "sha256-d5Xe2G7jyofkdkHGHRPjeQZbDYK8wm6rL/z0P8t6mso=",
      "url": "_framework/System.ComponentModel.Primitives.polnlun7xm.wasm"
    },
    {
      "hash": "sha256-wSmFX6ckTKv/MnwTYAUndqbUXSwY+TIrW7WjQrxmf2E=",
      "url": "_framework/System.ComponentModel.TypeConverter.vownp2h35d.wasm"
    },
    {
      "hash": "sha256-vV+EYK7Pqni5nIg0IYRySSM8DzWzXZVs4rDPDXjL7Fo=",
      "url": "_framework/System.Console.j8d5yvp8oh.wasm"
    },
    {
      "hash": "sha256-LllVahoPGSqThFojCwhVTdssBrB0dyYZ/TaHBX6WI2E=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.etb0bg8zbs.wasm"
    },
    {
      "hash": "sha256-LHmn3NZ0cYl/sD4s/EA26iSAYqDCycxgYdwt6suIKLM=",
      "url": "_framework/System.IO.Pipelines.wfn2m8uvna.wasm"
    },
    {
      "hash": "sha256-wZkMopGySYo6iZoNNEyNg7C3wsSSs05K5FYXbsgMONM=",
      "url": "_framework/System.Linq.Expressions.tljqkkp702.wasm"
    },
    {
      "hash": "sha256-wf88eJf4diJyrTnlBTwmyG/tv7QRkJsa7Wd1HQ796tA=",
      "url": "_framework/System.Linq.xgipa3ac9o.wasm"
    },
    {
      "hash": "sha256-4WzURtaK3tvCiW2rBLuMujQDpbX4s3bXixY5SlU/qc4=",
      "url": "_framework/System.Memory.jb0mw2garu.wasm"
    },
    {
      "hash": "sha256-ARqbacIvRbGsWyBNF2Peg2UNio5HTm+h3jzT13w4zCE=",
      "url": "_framework/System.Net.Http.3j5kt48xqz.wasm"
    },
    {
      "hash": "sha256-exVzRHBEzceG5mT//e3FmIs/YQwdpSLZxD5DYN0KTC4=",
      "url": "_framework/System.Net.Primitives.9zps8c8diq.wasm"
    },
    {
      "hash": "sha256-FSwjMWhrwH6LCf2ZL+E74CKwKoEHuJUdOpF2z0LwdaM=",
      "url": "_framework/System.ObjectModel.fbt23scx1i.wasm"
    },
    {
      "hash": "sha256-+iTTVpMTc25o2pw5UKsAUdEX6StZLiWUlHJf7T3qFgQ=",
      "url": "_framework/System.Private.CoreLib.agji6z85sb.wasm"
    },
    {
      "hash": "sha256-AGJ8WVEcIYC8jd016i81FdTIy5gtxvjMiAn7kSXAtCo=",
      "url": "_framework/System.Private.Uri.o653xw2w59.wasm"
    },
    {
      "hash": "sha256-8ynIFFjmwQTUAL9RdLjPTDSLEHjK9aYcuqoCsUM93uY=",
      "url": "_framework/System.Runtime.9ld1fr2wtd.wasm"
    },
    {
      "hash": "sha256-cTDlU0sLp3hCmTKUK2AVqrlAjuFjQveVBhCUZiIdUkc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lnedh9fxsl.wasm"
    },
    {
      "hash": "sha256-5roL5hgDxtpOyji6xusmx3evKf+54YuFbIJpejfq0XQ=",
      "url": "_framework/System.Text.Encodings.Web.q7l6i2z1r3.wasm"
    },
    {
      "hash": "sha256-u09LxBjP2nZ3WlfSCTM5N0AeBA4O3rS0xqwYrnjWIFU=",
      "url": "_framework/System.Text.Json.zi9ap6fqrt.wasm"
    },
    {
      "hash": "sha256-ajxc1hcb3pfQhxNT+NiRsn/GbJdvGZFJnoVgGvhHw5k=",
      "url": "_framework/System.Text.RegularExpressions.eqq5dwst3m.wasm"
    },
    {
      "hash": "sha256-/Imz/Enqa2AZc4T3k/CqtsM6674KRN9OUtvK4Nokhew=",
      "url": "_framework/System.wznexm8bk2.wasm"
    },
    {
      "hash": "sha256-LugLNzLiOratDH09k+ofDTlFFbxnn51qx3YpBTA8YDQ=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3MHpnImjcdbndre7BEBFmcZQ61mhKqldc9b5Bpp44Xo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-zrxfVswzVbeO5uCzmKKF3OONr7OzIJ3PhZOWz9t1Rs8=",
      "url": "_framework/dotnet.native.67rumul467.wasm"
    },
    {
      "hash": "sha256-MBW/zayfv+YU6mhH7y4b8NNU4D1EYd7nf9gYrFshnnY=",
      "url": "_framework/dotnet.native.st0ovrfdhi.js"
    },
    {
      "hash": "sha256-x+PnWU47EIr/zL3xxqIUMDJi/dy5904TVGunDqCvjIY=",
      "url": "_framework/dotnet.runtime.593bvuk5yc.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-FEcjGL5Vayj/vVFfza9Fl7AOyv/PLNTZoBBgB6QciYc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-M4KoOx+56VPY/Sd46Y1sysLZFaQUCJSzic3UEVYIhVs=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Eb3x9c0hzgRjfAvPRGagHnUQqbbrw0LXMhzqB2TaGwY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-2LdvSmO+iG02dlq+CnO7r+mVpTDl/R58HRg2FU9vBvo=",
      "url": "quizzes/index.json"
    },
    {
      "hash": "sha256-lqNVHvttTCC6G/i3cfNMWvPVKyk4lpCKi2otzNH1VZI=",
      "url": "quizzes/movies.json"
    },
    {
      "hash": "sha256-/jVyllVkxhv5TFJOiY4hooTg3WdwPoX1o//vEQuuZRM=",
      "url": "quizzes/planets.json"
    },
    {
      "hash": "sha256-Y3ZEZLOt6MbGy4ccujv1Kl0f8rUjJ/a05xBS2APKIUY=",
      "url": "quizzes/presidentit.json"
    }
  ]
};
