self.assetsManifest = {
  "version": "E3LSB9qc",
  "assets": [
    {
      "hash": "sha256-FqTaEL8BV9TzyL9nukyntnIBb53h0pKRWBtQP5F09MY=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-8+iZ8ET0xqP09OvKHJWYGFCjPZyiASD7Kl1tcdK6rj0=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-ncOUKD7BZJ98dNBVVETXRN4SlM/VkPai8rDVhzHQr9w=",
      "url": "_framework/ExtendedNumerics.BigDecimal.5y5qzs3sjq.wasm"
    },
    {
      "hash": "sha256-ocavDVRXn15rOKbp7apnJ5vocgjVBNP8oEPKeRi3Sek=",
      "url": "_framework/MathGame.Web.1g6g2om5fk.wasm"
    },
    {
      "hash": "sha256-+PdTWSbD8jCthn4tsEVWIK3jPuYTsHD2IULOOK401v4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.0mzztv196n.wasm"
    },
    {
      "hash": "sha256-a6D//LSZo++Sr0BCY+9DoE2UcS6BnSJH2zcLFAnHDMw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.hp8qpegwbx.wasm"
    },
    {
      "hash": "sha256-fzpFR/OEiVS5ejbYZ+MVUIjj2aMl3KvVj5zF+qBeNKY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5zdnnq478k.wasm"
    },
    {
      "hash": "sha256-3pnJTxqLptgbwwtDXjucHFH8BJ8TtE01zA07AjFLFow=",
      "url": "_framework/Microsoft.AspNetCore.Components.qt3y6bc72e.wasm"
    },
    {
      "hash": "sha256-hgxkC8VGNyBifVmeMfk7ZbBLt+KAMXLpOicRFf+K0lE=",
      "url": "_framework/Microsoft.CSharp.y532ww3794.wasm"
    },
    {
      "hash": "sha256-gKAPgp9mTgaOx2/W3+wNCZ/ku2VsndzpIgAZSBV3MSA=",
      "url": "_framework/Microsoft.Extensions.Configuration.8qxn5gf8x4.wasm"
    },
    {
      "hash": "sha256-954meUUHAnC2sYilT5FgEmCUid+xGtAWH3FirStj9mU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.p4ytjfgulb.wasm"
    },
    {
      "hash": "sha256-5utIvyrgcfjnzfpWMvPuQc+rwTV88lYWQQwvsHpz8w0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.evrc0jh359.wasm"
    },
    {
      "hash": "sha256-cfy5cXpIahWwdWJsOsyft7J2DdXO5RM1/N3PmsmZMLU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.znrynfj024.wasm"
    },
    {
      "hash": "sha256-Ggq1zvPzl6lMW/6h7CuUh+ogeZiFFs49aDdZOdZTLM4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.iudk3dhh52.wasm"
    },
    {
      "hash": "sha256-J250VgQvO3H705i37mYdiFNHPD/e3SslSugrMeEHUic=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.poumxfzvpb.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-exIrOoWDO4ZXWT/5fOejXbTbuIOutolQE0YklQyOjpI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3ew61mvqhf.wasm"
    },
    {
      "hash": "sha256-GJTxRmd6GTAZ3f5bfuAQKmqH1uCc+urCGWuYJ+VgCzw=",
      "url": "_framework/Microsoft.Extensions.Logging.Configuration.8squdxyhpp.wasm"
    },
    {
      "hash": "sha256-oShIxPuyaiF+LjvFxS4cNE6OeVRcxz4ediDtdGGVBf0=",
      "url": "_framework/Microsoft.Extensions.Logging.Console.hobeqvgz2p.wasm"
    },
    {
      "hash": "sha256-vx7Cxk6FwBd/8CCE0N0oMMxsO1iAjoW6rlPTF48ncwM=",
      "url": "_framework/Microsoft.Extensions.Logging.TraceSource.zv0p66zyvl.wasm"
    },
    {
      "hash": "sha256-vOabwuDRAfnbDTwDeWOoLA3iw3DuXFScX+k10ERzG7o=",
      "url": "_framework/Microsoft.Extensions.Logging.onfw24fhju.wasm"
    },
    {
      "hash": "sha256-MScO1pyQlA/j7QcpN4lYipDF755JJrYjO/4vO1lv7X8=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.foy1fxukg8.wasm"
    },
    {
      "hash": "sha256-DIObBRJhGCUFlX636UuO5ity3O95nW/l38KQZvblDUI=",
      "url": "_framework/Microsoft.Extensions.Options.sw3pvxg4i1.wasm"
    },
    {
      "hash": "sha256-AaUNPeWCmUYSh20W4X8Fdm1R64TV3W41hat/GJlV1rY=",
      "url": "_framework/Microsoft.Extensions.Primitives.lflqanr0jf.wasm"
    },
    {
      "hash": "sha256-M1qrUhdWLB+6f4w0nyrEazG7ekxANR+a10XUkoib/gU=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.hfmlhg1ldw.wasm"
    },
    {
      "hash": "sha256-W5Dg4hqmzUUSwApM0ONFhNf0QToANHBSMtrOoZishZ8=",
      "url": "_framework/Microsoft.JSInterop.n1qmr6hqiq.wasm"
    },
    {
      "hash": "sha256-GFs4aCAUJt2iuByS5VMDwztf99bhHJAA40A3SSYpDcs=",
      "url": "_framework/MudBlazor.o0997i2gw3.wasm"
    },
    {
      "hash": "sha256-BaCSYIxN1h6+NuO8c9qqHbARE82byDceeUr3eEGbYCQ=",
      "url": "_framework/NCalc.Core.bgz2w8oepy.wasm"
    },
    {
      "hash": "sha256-igBBpQwhurm+d02g9vJnSxzY/JLRRA2vQt7R0/tjh0E=",
      "url": "_framework/NCalc.Sync.2pzzwoy72b.wasm"
    },
    {
      "hash": "sha256-xBiGXu/xlScz/bx0ituIJ3HqANJgd5Bo+4NuCNyU/+0=",
      "url": "_framework/Parlot.cmqweztbu1.wasm"
    },
    {
      "hash": "sha256-9JSv2QmJTcv73EuP2drMtma42FuoQBAmRpY51n0myAQ=",
      "url": "_framework/System.Collections.Concurrent.4q6suzp655.wasm"
    },
    {
      "hash": "sha256-urL53UzoLOXhjCsKf1k1CPohrN7B9k34rz6PYb6Klfs=",
      "url": "_framework/System.Collections.Immutable.2pgfjeuy3d.wasm"
    },
    {
      "hash": "sha256-dken4W4c96kJ2jWTcLPYAh6shqXpQLGKLpkx9wWPWY8=",
      "url": "_framework/System.Collections.NonGeneric.y1z8cydvy9.wasm"
    },
    {
      "hash": "sha256-HNnAZA9YCPlE/hEgllycBpWNtoB3/GWKCUF8WcLfoFo=",
      "url": "_framework/System.Collections.Specialized.wf2rg9wjjk.wasm"
    },
    {
      "hash": "sha256-0ReS0LJ+9upH/loSmD8B3D4RgJPbT5VaTNv8x1XStzY=",
      "url": "_framework/System.Collections.p62vzmir1g.wasm"
    },
    {
      "hash": "sha256-Za6x8goA5EYeIcWOBG5JcBIyeba/ry+AvUyrd1+R5Fw=",
      "url": "_framework/System.ComponentModel.Annotations.lciaratgbu.wasm"
    },
    {
      "hash": "sha256-npnmRoPAcxzYxjkAuGVN29XFIdqndF8nuR6VwB8AbRI=",
      "url": "_framework/System.ComponentModel.Primitives.ailars334u.wasm"
    },
    {
      "hash": "sha256-mdfZLAWjlV1CHIy9Y1hKgNc3q3hAohYIrkQdoAv7xuE=",
      "url": "_framework/System.ComponentModel.TypeConverter.dntyle2fu4.wasm"
    },
    {
      "hash": "sha256-a85hiaz30M0/9OUzRnieQICeSKptaNOBrkmVoGTwJMc=",
      "url": "_framework/System.ComponentModel.zy0ms90z2w.wasm"
    },
    {
      "hash": "sha256-qGy0JyKmT948pZ3z1Vhx+WQdvStp+7ENlkFFQqhgM/o=",
      "url": "_framework/System.Console.cf8occb18t.wasm"
    },
    {
      "hash": "sha256-NLzZofHVXBq6VXZFeOK9/wfw6Z/9ts+KXEdYaqb2bGk=",
      "url": "_framework/System.Data.Common.8xaeh530ip.wasm"
    },
    {
      "hash": "sha256-/TvngwxDc7WsBG1/Vfu7yw6lV6IolfT7tOvnuEiot1Q=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.jke5vbum0m.wasm"
    },
    {
      "hash": "sha256-YS9yspeMXVIxGyy1wUUYYlpCOIqH/VWJIE9y/pqDGTQ=",
      "url": "_framework/System.Diagnostics.TraceSource.9y5doewnbe.wasm"
    },
    {
      "hash": "sha256-BkFbxv1I8Gi91w0amHcDVK8qokrPVZucalhRyHCi3iY=",
      "url": "_framework/System.Drawing.Primitives.m5nrd9qy4x.wasm"
    },
    {
      "hash": "sha256-F0ixmpqMP1a51H1asGAs900AuBIeemTmM9goerykkVw=",
      "url": "_framework/System.Drawing.l99g11my7u.wasm"
    },
    {
      "hash": "sha256-D13bL3jkSpvPSy0cGdyIFtMjdEW1R1aqXd4z1kUKDBA=",
      "url": "_framework/System.IO.Pipelines.p60wii4v3i.wasm"
    },
    {
      "hash": "sha256-UNLwqwkwaRmsNmUI7RmODMiNlcFYmjBcImmoWjKCgmM=",
      "url": "_framework/System.Linq.Expressions.c184g7ia6x.wasm"
    },
    {
      "hash": "sha256-4R8+kNHXtkvqNgc7YEuSywogfR7DX7vsQWe0NvwP4v8=",
      "url": "_framework/System.Linq.vwsrpf46sc.wasm"
    },
    {
      "hash": "sha256-bSZ97b9tQ+kVDFjod4Y3aETPqB8bfHE8Jzeba+7i06c=",
      "url": "_framework/System.Memory.52q6ts7rtg.wasm"
    },
    {
      "hash": "sha256-lLkOl1GU7hIwn604CVdlHo+z4nTj7NI4D46Ye/TY0rY=",
      "url": "_framework/System.Net.Http.k8m0p05pqt.wasm"
    },
    {
      "hash": "sha256-+kmyKoOgAl1MlZc+bDX6/ZO1+B+ZPkF8nEdNCX5YJMg=",
      "url": "_framework/System.Net.Primitives.6xdadyjvop.wasm"
    },
    {
      "hash": "sha256-ojKRidxkAT04FpgNm9qRtFybXXchzN24qNomOMWSv2w=",
      "url": "_framework/System.ObjectModel.e9lssrv4g5.wasm"
    },
    {
      "hash": "sha256-4YzTs7LwTzPFBbLTSmpzuE4MkWC4TyGtus+T48If8Sc=",
      "url": "_framework/System.Private.CoreLib.v4veads68p.wasm"
    },
    {
      "hash": "sha256-P+Wsc4zpItGPGSGLs9bG5GRgFGbYsQpr8F1S8nP5kyM=",
      "url": "_framework/System.Private.Uri.d1dfb8icb9.wasm"
    },
    {
      "hash": "sha256-808Czq//IhVMLO3KZpcle1OzyqJ/0mZxhweqaiFcUCM=",
      "url": "_framework/System.Private.Xml.zk00xbs7u6.wasm"
    },
    {
      "hash": "sha256-TL2H8c+dNXnEb68MHDdVvyclAS2p/8/ie/2m9pnVvGo=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.onajmcwoni.wasm"
    },
    {
      "hash": "sha256-Gid8ORv0tSY7i0YbIV4Uj/om+4LKxoSiv3SWya+jvNI=",
      "url": "_framework/System.Reflection.Emit.Lightweight.6xjxglsw9x.wasm"
    },
    {
      "hash": "sha256-ZyYqYIES12IgeHcR8JaNAHfbLfLmfRxaB+40ClZ5p5o=",
      "url": "_framework/System.Reflection.Primitives.35vndj1nrg.wasm"
    },
    {
      "hash": "sha256-ANxlVTpSYtRIG9U1tF3Fe+Td5kVqCX+eqBAYRjSDilw=",
      "url": "_framework/System.Runtime.47kfwevj8u.wasm"
    },
    {
      "hash": "sha256-MCRjCeayVfk7PLjpxolBTfj80eexQz38AjTKtqAQVU0=",
      "url": "_framework/System.Runtime.InteropServices.0gjjf3ybo0.wasm"
    },
    {
      "hash": "sha256-RCwjOsDHKssxMT8rHYj0tf9yQki2a+/u7PL4dXnouTA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.8jdb34iq28.wasm"
    },
    {
      "hash": "sha256-mKSA9QNXAPEPq9uRhYldVZ7CUGhZ7ZtTHT/A12JbVwE=",
      "url": "_framework/System.Runtime.Intrinsics.cboafbt3sm.wasm"
    },
    {
      "hash": "sha256-NVdux52NNpXrm6MFIZofrfWv/Ybmt7l9+TQS9AjLqZ4=",
      "url": "_framework/System.Runtime.Numerics.vzwvgoc3qe.wasm"
    },
    {
      "hash": "sha256-nYgkQjjKrDS6sxCr4S4OCAQ690fEgrD2jzY+N16rhrQ=",
      "url": "_framework/System.Runtime.Serialization.Formatters.reh1h2v6p4.wasm"
    },
    {
      "hash": "sha256-50Uu99y0aN+ZhLWp7ghDF0tqx84Q5Wtn8fYliGVp5MI=",
      "url": "_framework/System.Security.Cryptography.16sad4hdh2.wasm"
    },
    {
      "hash": "sha256-KOTIrepV9ejzFQawrr1LoFU8dR8CWPfbkE7J8xslw+8=",
      "url": "_framework/System.Text.Encodings.Web.s3t2856yks.wasm"
    },
    {
      "hash": "sha256-UwJYZypzSLIjyXEuVq8Rni+VUpu40KG5EFyPbNtTF+4=",
      "url": "_framework/System.Text.Json.v54tsrmg7c.wasm"
    },
    {
      "hash": "sha256-o2b1hnoLnmiNMfA8dCcZGPTpAzw0ZPgHmDoGz49nLcU=",
      "url": "_framework/System.Text.RegularExpressions.9pl6a76vfy.wasm"
    },
    {
      "hash": "sha256-OiObWs5Imvr4aQUyScKva8bVaKllvlBswESZmZPtSUk=",
      "url": "_framework/System.Threading.qft7wbe9n3.wasm"
    },
    {
      "hash": "sha256-5QZAjy4n7513fYxCXSXTsAkUmRsLiZ8m621Ot4k7FB0=",
      "url": "_framework/System.dqfxtvioy0.wasm"
    },
    {
      "hash": "sha256-ACibXDHBVH2Y/l7puXS6eyKFS1g+DLbYq9XV+HVTyMY=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-tgrZh46Y3JaZ+PyFFOnGPVYBjDDetP1k9QAKJlurdVI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HlUDSN0oXsH1WmjLNtyyvh9W0WQWWPGv3SJsHPJAwTE=",
      "url": "_framework/dotnet.native.etgrtk5jba.wasm"
    },
    {
      "hash": "sha256-CU8oL4L0VAwGe3hCyxZDy7keJq9dcsWED0JKqrvlUb4=",
      "url": "_framework/dotnet.native.l1ds2rhypd.js"
    },
    {
      "hash": "sha256-5oRcSUQSLbUYyq9jPgwB6domrDHYrvLX+53QxY+0y48=",
      "url": "_framework/dotnet.runtime.2hocyfcbj2.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-FEcjGL5Vayj/vVFfza9Fl7AOyv/PLNTZoBBgB6QciYc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-pwILBYNNDy5J8SAx91axRoyycahc2WMgSklBtFNsPPE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-glvGygN4Zz+Urp3XwET34/Lh6c8yrasuC7U7lPiulfg=",
      "url": "js/download.js"
    },
    {
      "hash": "sha256-6UQV05GOKNIca5OaVAC0KCreF+GZxZwiJRO0UnHlI1Q=",
      "url": "js/keyboard.js"
    },
    {
      "hash": "sha256-TUEwmJ1ePHpEL9SMyws/8QlArV1i4Yrat5+yR32jMiA=",
      "url": "js/mathwar.js"
    },
    {
      "hash": "sha256-Eb3x9c0hzgRjfAvPRGagHnUQqbbrw0LXMhzqB2TaGwY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-2LdvSmO+iG02dlq+CnO7r+mVpTDl/R58HRg2FU9vBvo=",
      "url": "quizzes/index.json"
    },
    {
      "hash": "sha256-lqNVHvttTCC6G/i3cfNMWvPVKyk4lpCKi2otzNH1VZI=",
      "url": "quizzes/movies.json"
    },
    {
      "hash": "sha256-/jVyllVkxhv5TFJOiY4hooTg3WdwPoX1o//vEQuuZRM=",
      "url": "quizzes/planets.json"
    },
    {
      "hash": "sha256-Y3ZEZLOt6MbGy4ccujv1Kl0f8rUjJ/a05xBS2APKIUY=",
      "url": "quizzes/presidentit.json"
    },
    {
      "hash": "sha256-/k9T2bA6qI/5wuyOp2MmfHD7IIrdY4MRzK4JLFqvbtk=",
      "url": "spotify-quizzes/Parhaat joulubiisit.csv"
    },
    {
      "hash": "sha256-Una5Hh7gD6ZPNbdTfb7tQT9NzsS353UgyqzO3AoPX88=",
      "url": "spotify-quizzes/hitster-suomi.csv"
    },
    {
      "hash": "sha256-VRzWS7h1SucIPBq0zKDJ14MiF2Y0hLPzPUgP6gO+/x8=",
      "url": "spotify-quizzes/suomi-musaa.csv"
    }
  ]
};
