self.assetsManifest = {
  "version": "rzW405Dc",
  "assets": [
    {
      "hash": "sha256-FqTaEL8BV9TzyL9nukyntnIBb53h0pKRWBtQP5F09MY=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-8+iZ8ET0xqP09OvKHJWYGFCjPZyiASD7Kl1tcdK6rj0=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-gIv3rkSTS7t+R5bMtcyMpbn3EuECRPgHZmWECRjdcd4=",
      "url": "_framework/CsvHelper.4zhysgmj1f.wasm"
    },
    {
      "hash": "sha256-qjRKSJWPAOGRtOc0NuJHlj8mbqPRUI5YghkoDJGGqIA=",
      "url": "_framework/MathGame.Web.uug4ppe4cs.wasm"
    },
    {
      "hash": "sha256-+PdTWSbD8jCthn4tsEVWIK3jPuYTsHD2IULOOK401v4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.0mzztv196n.wasm"
    },
    {
      "hash": "sha256-CPNUhtujKmG+moobgzCCnrD8/xtHZA+RNj9NO1bT2jc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.c3kpjymvfp.wasm"
    },
    {
      "hash": "sha256-b4WehjU2oEArR3zFzOgOaljI0/ripvIjGnZ77QFWgXw=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.v87b0fvkrf.wasm"
    },
    {
      "hash": "sha256-4FpmQF6bAUkkRmdZiBS5ysti8vuJoT9epxTwQWYkxps=",
      "url": "_framework/Microsoft.AspNetCore.Components.kjyoipo7kv.wasm"
    },
    {
      "hash": "sha256-APRVYELLPdJUumae8xRAcY16W+fr7NKhRTGxuuz3FGw=",
      "url": "_framework/Microsoft.CSharp.8ekzqqiuba.wasm"
    },
    {
      "hash": "sha256-KTJm6BIGGNfU41wPO6lMNMmUXnYFaXuEKjNy5ruOo0Y=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vqddrv70hy.wasm"
    },
    {
      "hash": "sha256-5MlajQ4o5ZSc9+Ao6RVRqh7puGzeJ+Y6tFld+O2tTZo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.8dcqd2oqkg.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-VuCbmTALXSkHmTYi8RNzMq9BkQ7KsOyNYXB3rWcE4ws=",
      "url": "_framework/Microsoft.Extensions.Configuration.ei421noawx.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-GRQq7ef/04D4/bLwnP0ipSoY8q2sLy/bt8ZvmIDJFf0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bfssx3wjn3.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-xAsaVwXtoAUgc6j2CpNOV+y4TK5LCap7czlBRRs6dhI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.0llacdaoge.wasm"
    },
    {
      "hash": "sha256-720xjccNSC/ixI8d5toBVmd5GGEzQAIN2LMqBmflaJw=",
      "url": "_framework/Microsoft.Extensions.Options.1cu2gj5cau.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-PNEDV+xipLuvR317S6a9u1afGzemESKRb3t3u2Wajts=",
      "url": "_framework/Microsoft.JSInterop.0hi1zeigqe.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-ww+ZuMRPlnpPK/dkS05W5QwYMse93ux/Xnctdvt/03I=",
      "url": "_framework/MudBlazor.flg3tvgets.wasm"
    },
    {
      "hash": "sha256-IpOocEh1xie3FhTABukExGVnlyT1T9fFNXB7aw2Rtmk=",
      "url": "_framework/System.Collections.2jvp9uay8j.wasm"
    },
    {
      "hash": "sha256-TzuYiUrcNz0l7d/oT1IQFWd0eYBB6LKjQHL8uZgAXDI=",
      "url": "_framework/System.Collections.Concurrent.voxnpq5yux.wasm"
    },
    {
      "hash": "sha256-phRrKoTEZum9EPN9rdcqRI15ki5niPoDaTILhh+Tb7A=",
      "url": "_framework/System.Collections.Immutable.qctnbzqwq3.wasm"
    },
    {
      "hash": "sha256-qFRJhWY3ISwvQbqz9gF2BOpVIHne+6UEfXDp5sgl2V0=",
      "url": "_framework/System.Collections.NonGeneric.4h8bxl63r1.wasm"
    },
    {
      "hash": "sha256-12ao+GEiD3upCdfXdUM3OzSX8oZdChoufdEXU9Jrhbc=",
      "url": "_framework/System.Collections.Specialized.ld8j80eg2l.wasm"
    },
    {
      "hash": "sha256-vQjTEVLxnxnVjf4cbtNqJ3jTqS9tbua4wzPbYG3Ebnk=",
      "url": "_framework/System.ComponentModel.Annotations.bynwy5ex8q.wasm"
    },
    {
      "hash": "sha256-CdUc3nx4tbSb+xfZIkkiOiReYWWoBjnw6+EYXeQ24Fs=",
      "url": "_framework/System.ComponentModel.Primitives.z5i0jf0hiu.wasm"
    },
    {
      "hash": "sha256-JudICmEIwjKsBodwTdumJU8SipNXESXMumGVKyRa+Pw=",
      "url": "_framework/System.ComponentModel.TypeConverter.2ue7ygjo8d.wasm"
    },
    {
      "hash": "sha256-D3qdQr+y+spdoDu0Q5Tr+qK6IHxI9v2AjMvstbB89Z0=",
      "url": "_framework/System.ComponentModel.n2b8k31o2o.wasm"
    },
    {
      "hash": "sha256-oGB2FhalGLCzXdB61F1rAUIChXU+NACMmctXMyYPR8c=",
      "url": "_framework/System.Console.kfjkcpn4ie.wasm"
    },
    {
      "hash": "sha256-D+NjEELv2Jl5AlYQ7n5QcZ2D6120PNecbcb2nJFI1Ac=",
      "url": "_framework/System.Data.Common.fcx96rgre9.wasm"
    },
    {
      "hash": "sha256-20MnV/nj/3JiyysUpagXdQ2XWsHPvhmacVcYcP0PUg0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.n1y6icprwn.wasm"
    },
    {
      "hash": "sha256-yvc4p/bOpGvHZrYLpsKLLmiBeXNqZ6x4v3m1GiWpuHk=",
      "url": "_framework/System.Diagnostics.TraceSource.6cgm46rgip.wasm"
    },
    {
      "hash": "sha256-bzXJoRVcRnyoxOCSMreix72mWvcA5CAA0Cl7Rd89ruM=",
      "url": "_framework/System.Drawing.5ziebqy3j0.wasm"
    },
    {
      "hash": "sha256-lqyZ72qhFrUryPd96z26GGtM3p3uH89cwmGxHKrPKbE=",
      "url": "_framework/System.Drawing.Primitives.um68xmouvq.wasm"
    },
    {
      "hash": "sha256-F7eq3vfkNdyf7BI0RJMCuDGtdhNgu4qn1GGWK5FvVz0=",
      "url": "_framework/System.IO.Pipelines.hqvxmp1tnr.wasm"
    },
    {
      "hash": "sha256-PG8ywou355hx2UobeOk7c7qi3eOvJqbJJzjU16hBShc=",
      "url": "_framework/System.Linq.Expressions.o9e8daa5nk.wasm"
    },
    {
      "hash": "sha256-v+jD3J5AFgnIRH92ahvbJpL0oXq8z7lnr02qvECR9zo=",
      "url": "_framework/System.Linq.xsz4lptucq.wasm"
    },
    {
      "hash": "sha256-1aQtWAsFOnyv0iSp8sXIozV5TRVWg7q+Y2v5463QOak=",
      "url": "_framework/System.Memory.3q0uc4e4j8.wasm"
    },
    {
      "hash": "sha256-rWhpr4CnAjslOd+kSCHrk5rMXnIM7Tbmx8sGvSVLS0A=",
      "url": "_framework/System.Net.Http.5ubjaz3rdf.wasm"
    },
    {
      "hash": "sha256-/FmecRu5Wfb7p4wjY3KDbGzMWRfNbwsnnAnzdbPF9b8=",
      "url": "_framework/System.Net.Primitives.gd20ym2wiq.wasm"
    },
    {
      "hash": "sha256-KG/3NpSpadijH0Dh/A0cGUwbRgpqOaotODJymWDjqa4=",
      "url": "_framework/System.ObjectModel.wyjngb7p32.wasm"
    },
    {
      "hash": "sha256-wBSYBUMZCaK4uQDnQlgQPFCF/OrGToigSynPtksE628=",
      "url": "_framework/System.Private.CoreLib.gss6on83kk.wasm"
    },
    {
      "hash": "sha256-pdIm8mGgg1I/3flGOwsH39Glyal398iUMLF1M5jljCw=",
      "url": "_framework/System.Private.Uri.xxinf1089s.wasm"
    },
    {
      "hash": "sha256-GPK/+s2V3VEr+19My6Dh3PTbbZYQVMy3miQ/iuDqTBo=",
      "url": "_framework/System.Private.Xml.wugb0mnxh7.wasm"
    },
    {
      "hash": "sha256-uK7cy5l8judDq3oY6y3b53nFsPOAvcuOWxbAAlJPzMQ=",
      "url": "_framework/System.Runtime.4x5bo14f5r.wasm"
    },
    {
      "hash": "sha256-8v7jVijrzRlaTmvdds4+ZNyPL5DYfnYnzFYT2HtkqwM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.u9tzo6t7zm.wasm"
    },
    {
      "hash": "sha256-oNKKZmjCO5i8uJ+BDolFk/N48n9UbsVduxjsWaDPGDc=",
      "url": "_framework/System.Runtime.Numerics.8ajjl09647.wasm"
    },
    {
      "hash": "sha256-a0JAY5+9fTuPHgSDBQHtDqniyt7l9M2eaR07qWglzyA=",
      "url": "_framework/System.Runtime.Serialization.Formatters.1p96fuurrj.wasm"
    },
    {
      "hash": "sha256-ppEcePbCU2PPVO8nk4rbpQZb/CnrS9UK1foQuHYt/3U=",
      "url": "_framework/System.Security.Cryptography.69lnriexyh.wasm"
    },
    {
      "hash": "sha256-oAvGjE7zOfELanuhXBazvipywX/fnbrfBmWPDH/R3bw=",
      "url": "_framework/System.Text.Encodings.Web.8qvkegu1ci.wasm"
    },
    {
      "hash": "sha256-HQhcTTIqflHTqXraebLONczzNkUUZKh7t0+cvsay8bM=",
      "url": "_framework/System.Text.Json.bqf5tzf6hf.wasm"
    },
    {
      "hash": "sha256-ufwkLimnqkmY756+NnZxL3EScj1VhCHhuuMy1jacCn0=",
      "url": "_framework/System.Text.RegularExpressions.78exx3xexn.wasm"
    },
    {
      "hash": "sha256-WdovTmoCqEowsOYWWzRAXZHH2IUUTYx/q98g1qUBC/k=",
      "url": "_framework/System.Threading.51bubf8ll2.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-+yaqXxK/I1lGERUOux0jaH/P2kue47DsMG7M/qvc1eQ=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-p9eEzXhQIsI0a5bBJhfzW15iRafgplTxT8XrO5FiH9o=",
      "url": "_framework/dotnet.native.noby4tlk4d.js"
    },
    {
      "hash": "sha256-Po2dalLvTpf5jAS+jt0TzuBYybYiL1F6qAacZJ8UAdo=",
      "url": "_framework/dotnet.native.qe75a9vfqn.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-FEcjGL5Vayj/vVFfza9Fl7AOyv/PLNTZoBBgB6QciYc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-pNpCLeV6w79RYhpWr9JZhwW5hNUE3JpMYF9eXxxuwaQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-glvGygN4Zz+Urp3XwET34/Lh6c8yrasuC7U7lPiulfg=",
      "url": "js/download.js"
    },
    {
      "hash": "sha256-IJ7ohKOTxVLnSx4IXjLvRjiUhGHz4hV3ykraujtrTdw=",
      "url": "js/keyboard.js"
    },
    {
      "hash": "sha256-Eb3x9c0hzgRjfAvPRGagHnUQqbbrw0LXMhzqB2TaGwY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-2LdvSmO+iG02dlq+CnO7r+mVpTDl/R58HRg2FU9vBvo=",
      "url": "quizzes/index.json"
    },
    {
      "hash": "sha256-lqNVHvttTCC6G/i3cfNMWvPVKyk4lpCKi2otzNH1VZI=",
      "url": "quizzes/movies.json"
    },
    {
      "hash": "sha256-/jVyllVkxhv5TFJOiY4hooTg3WdwPoX1o//vEQuuZRM=",
      "url": "quizzes/planets.json"
    },
    {
      "hash": "sha256-Y3ZEZLOt6MbGy4ccujv1Kl0f8rUjJ/a05xBS2APKIUY=",
      "url": "quizzes/presidentit.json"
    }
  ]
};
